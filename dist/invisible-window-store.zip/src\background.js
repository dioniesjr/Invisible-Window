chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['enabled'], (data) => {
    if (typeof data.enabled !== 'boolean') {
      chrome.storage.sync.set({ enabled: true });
    }
  });
});
