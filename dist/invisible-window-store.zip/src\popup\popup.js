const enabledEl = document.getElementById('enabled');
const statusEl = document.getElementById('status');

function setStatus(text) {
  statusEl.textContent = text || '';
}

function load() {
  chrome.storage.sync.get({ enabled: true }, (data) => {
    enabledEl.checked = data.enabled !== false;
  });
}

function save() {
  chrome.storage.sync.set({ enabled: enabledEl.checked }, () => {
    setStatus('Saved. Hard-refresh open tabs.');
  });
}

enabledEl.addEventListener('change', save);
load();
